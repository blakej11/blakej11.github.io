#ifndef	_VECSIZES_H
#define	_VECSIZES_H

/*
 * Yep, this is all it takes to implement the 1-D MSTP algorithm.
 */

#define	BOX_DIMENSIONS		1
#define	DATA_DIMENSIONS		1

#endif	/* _VECSIZES_H */
