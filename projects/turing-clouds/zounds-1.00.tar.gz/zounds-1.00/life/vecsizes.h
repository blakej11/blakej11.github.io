#ifndef	_VECSIZES_H
#define	_VECSIZES_H

#define	DATA_DIMENSIONS		1

#endif	/* _VECSIZES_H */
