#ifndef	_SHARED_H
#define	_SHARED_H

/*
 * This header file is #include'd by both C and OpenCL code.
 */

#define	THRESH_SCALE	100	/* units of threshold scaling */

#endif	/* _SHARED_H */
