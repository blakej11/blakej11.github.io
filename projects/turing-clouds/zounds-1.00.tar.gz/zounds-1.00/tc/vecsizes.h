#ifndef	_VECSIZES_H
#define	_VECSIZES_H

#define	BOX_DIMENSIONS		4
#define	DATA_DIMENSIONS		4

#endif	/* _VECSIZES_H */
